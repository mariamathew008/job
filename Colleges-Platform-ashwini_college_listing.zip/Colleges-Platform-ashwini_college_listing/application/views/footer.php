<div id="footer">
<!-- Main -->
	<div class="container">
		             <div class="five columns">
                <aside id="text-3" class="footer-widget widget_text"><h4>About</h4>			<div class="textwidget"><p>WorkScout is a fully functioning job board Theme for WordPress developed with the popular free WordPress Plugin WP Job Manager.</p>
<a href="https://themeforest.net/item/workscout-job-board-wordpress-theme/13591801?ref=purethemes" class="button">Learn More</a></div>
		</aside>            </div>
                     <div class="three columns">
                <aside id="nav_menu-2" class="footer-widget widget_nav_menu"><h4>For Candidates</h4><div class="menu-footer-for-candidates-container"><ul id="menu-footer-for-candidates" class="menu"><li id="menu-item-194" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-194"><a href="#">Browse Jobs</a></li>
<li id="menu-item-195" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-195"><a href="#">Browse Categories</a></li>
<li id="menu-item-196" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-196"><a href="#">Submit Resume</a></li>
<li id="menu-item-197" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-197"><a href="#">Candidate Dashboard</a></li>
<li id="menu-item-198" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-198"><a href="#">Job Alerts</a></li>
<li id="menu-item-199" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-199"><a href="#">My Bookmarks</a></li>
</ul></div></aside>            </div>
                     <div class="three columns">
                <aside id="nav_menu-3" class="footer-widget widget_nav_menu"><h4>For Employers</h4><div class="menu-footer-for-employers-container"><ul id="menu-footer-for-employers" class="menu"><li id="menu-item-170" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-170"><a href="#">Browse Candidates</a></li>
<li id="menu-item-172" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-172"><a href="#">Employer Dashboard</a></li>
<li id="menu-item-171" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-171"><a href="#">Add Job</a></li>
<li id="menu-item-173" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-173"><a href="#">Job Packages</a></li>
</ul></div></aside>            </div>
                     <div class="five columns">
                <aside id="nav_menu-4" class="footer-widget widget_nav_menu"><h4>Other</h4><div class="menu-footer-other-container"><ul id="menu-footer-other" class="menu"><li id="menu-item-154" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-154"><a href="http://simplyprint.in/shortcodes/">Shortcodes</a></li>
<li id="menu-item-174" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-174"><a href="#">Job Page</a></li>
<li id="menu-item-175" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-175"><a href="#">Job Page Alternative</a></li>
<li id="menu-item-187" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-187"><a href="#">Resume Page</a></li>
<li id="menu-item-188" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-188"><a href="#">Blog</a></li>
<li id="menu-item-155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155"><a href="http://simplyprint.in/contact/">Contact</a></li>
</ul></div></aside>            </div>
        	</div>

	<!-- Bottom -->
	<div class="container">
		<div class="footer-bottom">
			<div class="sixteen columns">
				
                <h4>Follow us</h4><ul class="social-icons"><li><a target="_blank" class="facebook" title="Facebook" href="#"><i class="icon-facebook"></i></a></li><li><a target="_blank" class="twitter" title="Twitter" href="#"><i class="icon-twitter"></i></a></li><li><a target="_blank" class="gplus" title="GooglePlus" href="#"><i class="icon-gplus"></i></a></li><li><a target="_blank" class="linkedin" title="LinkdedIn" href="#"><i class="icon-linkedin"></i></a></li></ul>				
				<div class="copyrights">© Theme by Purethemes.net. All Rights Reserved.</div>
			</div>
		</div>
	</div>

</div>